-- University Project Portal - Supabase PostgreSQL schema + Row Level Security
-- Run this file in Supabase SQL Editor.

create extension if not exists pgcrypto;

do $$ begin
  create type public.user_role as enum ('student','lecturer','admin');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.topic_status as enum ('available','full','pending_approval','approved','rejected');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.project_status as enum ('active','completed','suspended');
exception when duplicate_object then null; end $$;
do $$ begin
  create type public.submission_status as enum ('pending_review','reviewed','approved','rejected');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  email text not null unique,
  role public.user_role not null default 'student',
  department text,
  matric_number text unique,
  staff_id text unique,
  specialization text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.topics (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  lecturer_id uuid not null references public.profiles(id) on delete restrict,
  department text not null,
  research_area text not null,
  max_students integer not null check (max_students > 0),
  enrolled_students integer not null default 0 check (enrolled_students >= 0),
  status public.topic_status not null default 'pending_approval',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null unique references public.profiles(id) on delete cascade,
  topic_id uuid not null unique references public.topics(id) on delete restrict,
  supervisor_id uuid not null references public.profiles(id) on delete restrict,
  status public.project_status not null default 'active',
  overall_progress integer not null default 0 check (overall_progress between 0 and 100),
  supervisor_approval_status text not null default 'Pending',
  milestones jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.projects(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  chapter_label text not null,
  file_name text not null,
  file_path text not null,
  file_size bigint,
  status public.submission_status not null default 'pending_review',
  feedback text,
  uploaded_at timestamptz not null default now(),
  reviewed_at timestamptz
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  lecturer_id uuid not null references public.profiles(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(student_id, lecturer_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  type text not null default 'text' check(type in ('text','image','video')),
  content text not null,
  media_url text,
  sent_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete cascade,
  type text not null check(type in ('warning','info','success','error')),
  title text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

create or replace function public.set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

drop trigger if exists profiles_updated_at on public.profiles;
create trigger profiles_updated_at before update on public.profiles for each row execute function public.set_updated_at();
drop trigger if exists topics_updated_at on public.topics;
create trigger topics_updated_at before update on public.topics for each row execute function public.set_updated_at();
drop trigger if exists projects_updated_at on public.projects;
create trigger projects_updated_at before update on public.projects for each row execute function public.set_updated_at();
drop trigger if exists conversations_updated_at on public.conversations;
create trigger conversations_updated_at before update on public.conversations for each row execute function public.set_updated_at();

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles(id,name,email,role,department,matric_number,staff_id,specialization)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)),
    new.email,
    coalesce((new.raw_app_meta_data->>'role')::public.user_role, (new.raw_user_meta_data->>'role')::public.user_role, 'student'),
    new.raw_user_meta_data->>'department',
    new.raw_user_meta_data->>'matricNumber',
    new.raw_user_meta_data->>'staffId',
    new.raw_user_meta_data->>'specialization'
  ) on conflict (id) do update set name=excluded.name,email=excluded.email,role=excluded.role,department=excluded.department,matric_number=excluded.matric_number,staff_id=excluded.staff_id,specialization=excluded.specialization;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

-- Helper for role checks inside RLS.
create or replace function public.current_user_role() returns public.user_role
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

alter table public.profiles enable row level security;
alter table public.topics enable row level security;
alter table public.projects enable row level security;
alter table public.submissions enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.notifications enable row level security;

-- Profiles
create policy profiles_select_self_or_admin on public.profiles for select to authenticated using (id=auth.uid() or public.current_user_role()='admin');
create policy profiles_update_self_or_admin on public.profiles for update to authenticated using (id=auth.uid() or public.current_user_role()='admin') with check (id=auth.uid() or public.current_user_role()='admin');

-- Topics
create policy topics_select_authenticated on public.topics for select to authenticated using (status in ('available','approved','full') or lecturer_id=auth.uid() or public.current_user_role()='admin');
create policy topics_insert_lecturer on public.topics for insert to authenticated with check (lecturer_id=auth.uid() and public.current_user_role()='lecturer');
create policy topics_update_owner_or_admin on public.topics for update to authenticated using (lecturer_id=auth.uid() or public.current_user_role()='admin') with check (lecturer_id=auth.uid() or public.current_user_role()='admin');

-- Projects
create policy projects_select_participant_or_admin on public.projects for select to authenticated using (student_id=auth.uid() or supervisor_id=auth.uid() or public.current_user_role()='admin');
create policy projects_insert_student_or_admin on public.projects for insert to authenticated with check (student_id=auth.uid() or public.current_user_role()='admin');
create policy projects_update_participant_or_admin on public.projects for update to authenticated using (student_id=auth.uid() or supervisor_id=auth.uid() or public.current_user_role()='admin') with check (student_id=auth.uid() or supervisor_id=auth.uid() or public.current_user_role()='admin');

-- Submissions
create policy submissions_select_participant_or_admin on public.submissions for select to authenticated using (student_id=auth.uid() or exists(select 1 from public.projects p where p.id=project_id and p.supervisor_id=auth.uid()) or public.current_user_role()='admin');
create policy submissions_insert_student on public.submissions for insert to authenticated with check (student_id=auth.uid());
create policy submissions_update_reviewer on public.submissions for update to authenticated using (exists(select 1 from public.projects p where p.id=project_id and p.supervisor_id=auth.uid()) or public.current_user_role()='admin') with check (exists(select 1 from public.projects p where p.id=project_id and p.supervisor_id=auth.uid()) or public.current_user_role()='admin');

-- Conversations and messages
create policy conversations_select_participant_or_admin on public.conversations for select to authenticated using (student_id=auth.uid() or lecturer_id=auth.uid() or public.current_user_role()='admin');
create policy conversations_insert_participant on public.conversations for insert to authenticated with check (student_id=auth.uid() or lecturer_id=auth.uid());
create policy conversations_update_participant on public.conversations for update to authenticated using (student_id=auth.uid() or lecturer_id=auth.uid() or public.current_user_role()='admin') with check (student_id=auth.uid() or lecturer_id=auth.uid() or public.current_user_role()='admin');
create policy messages_select_conversation_participant on public.messages for select to authenticated using (exists(select 1 from public.conversations c where c.id=conversation_id and (c.student_id=auth.uid() or c.lecturer_id=auth.uid())) or public.current_user_role()='admin');
create policy messages_insert_conversation_participant on public.messages for insert to authenticated with check (sender_id=auth.uid() and exists(select 1 from public.conversations c where c.id=conversation_id and (c.student_id=auth.uid() or c.lecturer_id=auth.uid())));

-- Notifications
create policy notifications_select_owner_or_admin on public.notifications for select to authenticated using (user_id=auth.uid() or user_id is null or public.current_user_role()='admin');
create policy notifications_update_owner_or_admin on public.notifications for update to authenticated using (user_id=auth.uid() or public.current_user_role()='admin') with check (user_id=auth.uid() or public.current_user_role()='admin');

-- Storage
insert into storage.buckets (id,name,public) values ('project-files','project-files',false) on conflict (id) do nothing;
create policy project_files_select_owner_or_admin on storage.objects for select to authenticated using (bucket_id='project-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.current_user_role()='admin'));
create policy project_files_insert_owner on storage.objects for insert to authenticated with check (bucket_id='project-files' and (storage.foldername(name))[1]=auth.uid()::text);
create policy project_files_update_owner_or_admin on storage.objects for update to authenticated using (bucket_id='project-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.current_user_role()='admin')) with check (bucket_id='project-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.current_user_role()='admin'));
create policy project_files_delete_owner_or_admin on storage.objects for delete to authenticated using (bucket_id='project-files' and ((storage.foldername(name))[1]=auth.uid()::text or public.current_user_role()='admin'));

-- Useful indexes
create index if not exists topics_lecturer_idx on public.topics(lecturer_id);
create index if not exists projects_supervisor_idx on public.projects(supervisor_id);
create index if not exists submissions_student_idx on public.submissions(student_id);
create index if not exists submissions_project_idx on public.submissions(project_id);
create index if not exists messages_conversation_idx on public.messages(conversation_id, sent_at);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
