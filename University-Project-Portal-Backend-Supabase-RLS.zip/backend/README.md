# University Project Portal Backend — Supabase Edition

Express + TypeScript backend for the supplied University Project Portal frontend, migrated from MongoDB/Mongoose to Supabase PostgreSQL, Supabase Auth, and Supabase Storage.

## Stack
- Node.js + Express.js
- TypeScript
- Supabase PostgreSQL
- Supabase Auth (email/password)
- Supabase Storage
- Row Level Security (RLS)
- Zod validation
- Multer for temporary multipart uploads before Storage upload

## Structure
The requested `config`, `controllers`, `routes`, `models`, `services`, `middlewares`, `utils`, `types`, `validators`, `app.ts`, and `server.ts` structure is retained. `models/` now contains TypeScript domain types instead of Mongoose schemas.

## 1. Create the Supabase database
1. Create a Supabase project.
2. Open **SQL Editor**.
3. Run `supabase/schema.sql` in full.
4. Confirm that the `project-files` private Storage bucket exists.
5. In Supabase Authentication settings, email/password authentication must be enabled. The backend uses `admin.createUser` with `email_confirm: true`, so users created by this backend do not need a confirmation email before first login.

## 2. Environment variables
Copy `.env.example` to `.env` and set:

```env
SUPABASE_URL=https://YOUR-PROJECT.supabase.co
SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
SUPABASE_SERVICE_ROLE_KEY=YOUR_SUPABASE_SERVICE_ROLE_KEY
SUPABASE_STORAGE_BUCKET=project-files
FRONTEND_URL=http://localhost:5173
```

**Never expose `SUPABASE_SERVICE_ROLE_KEY` to the frontend or commit it to Git.**

## 3. Install and run

```bash
npm install
npm run dev
```

Production:

```bash
npm run build
npm start
```

## 4. Frontend
Set the frontend environment variable to:

```env
VITE_API_BASE_URL=http://localhost:5000/api
```

The frontend can continue using the same REST endpoints. The `token` returned by login/register is now a Supabase Auth access token, so send it as:

```http
Authorization: Bearer <token>
```

## Authentication
Supabase Auth owns password hashing, sessions, access tokens and refresh tokens. The `profiles` table stores application-specific fields such as role, department, matric number and staff ID.

## RLS
All application tables have RLS enabled. Policies restrict records by authenticated Supabase user ID and application role. The private `project-files` Storage bucket also has RLS policies.

The Express backend uses the Supabase **service-role key** for server-side operations after it has authenticated and authorized the request. Supabase service-role access intentionally bypasses RLS; therefore the backend's `authenticate`/`authorize` middleware is the server-side security boundary, while the SQL policies protect direct client-side Supabase access and Storage access.

Do not put the service-role key in the frontend.

## Implemented API areas
- Authentication: login, register, logout
- User profile: current user
- Topics: list, lecturer topics, create, select, student proposal
- Student project: current project
- Submissions: list, upload to Supabase Storage, review
- Messaging: conversations, threads, text messages, media upload
- Lecturer: statistics and assigned students
- Admin: statistics, notifications, unallocated students, supervisors, allocations, reports and CSV export

## Important production notes
- Restrict who can register as `admin`; the sample registration endpoint retains the original frontend contract.
- Rotate the service-role key if it is ever exposed.
- Consider moving allocation/topic selection into PostgreSQL RPC functions for stronger transaction/locking guarantees when multiple users can select the same topic simultaneously.
