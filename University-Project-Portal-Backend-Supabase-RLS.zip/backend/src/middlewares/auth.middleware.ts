import type {Request,Response,NextFunction} from 'express';
import { supabaseAdmin } from '../config/db.js';
import { getUser } from '../services/user.service.js';
import AppError from '../utils/AppError.js';
import type { Role } from '../models/user.model.js';

export async function authenticate(req:Request,_res:Response,next:NextFunction){
  try {
    const h=req.headers.authorization;
    if(!h?.startsWith('Bearer ')) throw new AppError('Authentication required.',401);
    const token=h.slice(7);
    const { data, error } = await supabaseAdmin.auth.getUser(token);
    if(error || !data.user) throw new AppError('Invalid or expired token.',401);
    const profile=await getUser(data.user.id);
    if(!profile) throw new AppError('User profile not found.',401);
    req.user={id:data.user.id,role:profile.role as Role};
    req.accessToken=token;
    next();
  } catch(e) { next(e instanceof AppError?e:new AppError('Invalid or expired token.',401)); }
}

export function authorize(...roles:string[]){return (req:Request,_res:Response,next:NextFunction)=>{if(!req.user||!roles.includes(req.user.role))return next(new AppError('You do not have permission to perform this action.',403));next();};}
