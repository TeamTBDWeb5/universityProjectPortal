import multer from 'multer';
import { env } from '../config/env.js';
const storage=multer.diskStorage({destination:'uploads',filename:(_r,f,cb)=>cb(null,`${Date.now()}-${f.originalname.replace(/[^a-zA-Z0-9._-]/g,'_')}`)});
export const upload=multer({storage,limits:{fileSize:env.maxFileSizeMb*1024*1024}});
