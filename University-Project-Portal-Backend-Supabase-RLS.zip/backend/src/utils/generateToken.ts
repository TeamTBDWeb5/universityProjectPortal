// Authentication is handled by Supabase Auth. This file is retained for the requested project structure.
export function generateToken(accessToken: string) { return accessToken; }
