export type NotificationSeverity = 'warning' | 'info' | 'success' | 'error';
export interface NotificationRecord { id: string; userId?: string | null; type: NotificationSeverity; title: string; message: string; read: boolean; createdAt: string; }
