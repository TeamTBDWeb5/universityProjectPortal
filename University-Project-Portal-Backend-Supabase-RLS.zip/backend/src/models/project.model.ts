export type ProjectStatus = 'active' | 'completed' | 'suspended';
export interface Milestone { id?: string; label: string; status: 'completed' | 'in_progress' | 'pending'; percentage: number; dueDate?: string | null; }
export interface ProjectRecord { id: string; studentId: string; topicId: string; supervisorId: string; status: ProjectStatus; overallProgress: number; supervisorApprovalStatus: string; milestones: Milestone[]; createdAt: string; updatedAt: string; }
