export type MessageType = 'text' | 'image' | 'video';
export interface ConversationRecord { id: string; studentId: string; lecturerId: string; projectId?: string | null; createdAt: string; updatedAt: string; }
export interface MessageRecord { id: string; conversationId: string; senderId: string; type: MessageType; content: string; mediaUrl?: string | null; sentAt: string; }
