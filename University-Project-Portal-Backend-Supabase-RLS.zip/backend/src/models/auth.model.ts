export interface AuthResponse {
  token: string;
  refreshToken?: string;
  user: unknown;
}
