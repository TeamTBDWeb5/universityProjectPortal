export type TopicStatus = 'available' | 'full' | 'pending_approval' | 'approved' | 'rejected';
export interface TopicRecord { id: string; title: string; description: string; lecturerId: string; department: string; researchArea: string; maxStudents: number; enrolledStudents: number; status: TopicStatus; createdAt: string; updatedAt: string; lecturer?: any; }
