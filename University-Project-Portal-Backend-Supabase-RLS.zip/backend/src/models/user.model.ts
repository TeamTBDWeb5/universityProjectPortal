export type Role = 'student' | 'lecturer' | 'admin';

export interface UserRecord {
  id: string;
  name: string;
  email: string;
  role: Role;
  department?: string | null;
  matricNumber?: string | null;
  staffId?: string | null;
  specialization?: string | null;
  createdAt?: string;
  updatedAt?: string;
}

export function publicUser(u: UserRecord) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    department: u.department ?? undefined,
    matricNumber: u.matricNumber ?? undefined,
    staffId: u.staffId ?? undefined,
    specialization: u.specialization ?? undefined,
  };
}
