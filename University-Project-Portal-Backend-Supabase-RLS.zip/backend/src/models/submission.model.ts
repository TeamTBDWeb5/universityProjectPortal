export type SubmissionStatus = 'pending_review' | 'reviewed' | 'approved' | 'rejected';
export interface SubmissionRecord { id: string; projectId: string; studentId: string; chapterLabel: string; fileName: string; filePath: string; fileSize?: number; status: SubmissionStatus; feedback?: string | null; uploadedAt: string; reviewedAt?: string | null; }
