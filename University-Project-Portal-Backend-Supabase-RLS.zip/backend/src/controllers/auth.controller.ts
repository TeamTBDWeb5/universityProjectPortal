import type {Request,Response} from 'express';
import {login,register,revokeUserSessions} from '../services/auth.service.js';
import {z} from 'zod';
const loginSchema=z.object({identifier:z.string().min(1),identifierType:z.enum(['id','email']),password:z.string().min(1)});
const regSchema=z.object({role:z.enum(['student','lecturer','admin']),name:z.string().min(2),identifier:z.string().min(2),identifierType:z.enum(['id','email']),department:z.string().optional(),password:z.string().min(8),confirmPassword:z.string().min(8)});
export async function loginController(req:Request,res:Response){res.json(await login(loginSchema.parse(req.body)));}
export async function registerController(req:Request,res:Response){res.status(201).json(await register(regSchema.parse(req.body)));}
export async function logoutController(req:Request,res:Response){await revokeUserSessions(req.user!.id);res.json({message:'Logged out successfully.'});}
