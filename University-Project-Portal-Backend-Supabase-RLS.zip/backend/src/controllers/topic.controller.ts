import type {Request,Response} from 'express';
import { createTopic, listTopics, mine, proposeTopic, selectTopic } from '../services/topic.service.js';
export async function list(req:Request,res:Response){res.json(await listTopics(req.query));}
export async function mineController(req:Request,res:Response){res.json(await mine(req.user!.id));}
export async function create(req:Request,res:Response){res.status(201).json(await createTopic(req.user!.id,req.body));}
export async function select(req:Request,res:Response){await selectTopic(req.user!.id,req.params.topicId);res.status(201).json({message:'Topic selected successfully.'});}
export async function propose(req:Request,res:Response){const t=await proposeTopic(req.user!.id,req.body);res.status(201).json({message:'Topic proposal submitted.',topicId:t.id});}
