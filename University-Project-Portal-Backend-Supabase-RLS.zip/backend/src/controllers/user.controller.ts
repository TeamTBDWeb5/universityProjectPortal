import type {Request,Response} from 'express';
import { getUser, publicUser } from '../services/user.service.js';
export async function me(req:Request,res:Response){const u=await getUser(req.user!.id);if(!u)return res.status(404).json({message:'User not found.'});res.json(publicUser(u));}
