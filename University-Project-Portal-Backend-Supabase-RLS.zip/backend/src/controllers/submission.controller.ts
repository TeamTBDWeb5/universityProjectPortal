import type {Request,Response} from 'express'; import * as service from '../services/submission.service.js';
export async function list(req:Request,res:Response){res.json(await service.list(req.user!.role==='student'?req.user!.id:undefined));}
export async function upload(req:Request,res:Response){if(!req.file)return res.status(400).json({message:'A file is required.'});res.status(201).json(await service.upload(req.user!.id,req.file,String(req.body.chapterLabel??'Project Submission')));}
export async function review(req:Request,res:Response){res.json(await service.review(req.user!.id,req.user!.role,req.params.submissionId,String(req.body.feedback??''),String(req.body.status??'')));}
