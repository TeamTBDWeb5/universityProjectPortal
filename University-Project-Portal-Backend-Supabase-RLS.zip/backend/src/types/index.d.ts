export type Role = 'student' | 'lecturer' | 'admin';

declare global {
  namespace Express {
    interface Request {
      user?: { id: string; role: Role };
      accessToken?: string;
    }
  }
}

export {};
