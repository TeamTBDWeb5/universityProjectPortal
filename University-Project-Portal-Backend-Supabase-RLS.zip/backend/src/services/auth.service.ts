import { supabaseAdmin } from '../config/db.js';
import { findByIdentifier, publicUser, createUser } from './user.service.js';
import AppError from '../utils/AppError.js';

export async function login(data:any) {
  const profile = await findByIdentifier(data.identifier, data.identifierType);
  if (!profile) throw new AppError('Invalid identifier or password.', 401);
  const { data: session, error } = await supabaseAdmin.auth.signInWithPassword({ email: profile.email, password: data.password });
  if (error || !session.session) throw new AppError('Invalid identifier or password.', 401);
  return { token: session.session.access_token, refreshToken: session.session.refresh_token, user: publicUser(profile) };
}

export async function register(data:any) {
  const profile = await createUser(data);
  const { data: session, error } = await supabaseAdmin.auth.signInWithPassword({ email: profile.email, password: data.password });
  if (error || !session.session) throw new AppError(error?.message ?? 'Account created but login failed.', 500);
  return { token: session.session.access_token, refreshToken: session.session.refresh_token, user: publicUser(profile) };
}

export async function revokeUserSessions(userId:string) {
  const { error } = await supabaseAdmin.auth.admin.signOut(userId, 'global');
  if (error) throw new AppError(error.message, 500);
}
