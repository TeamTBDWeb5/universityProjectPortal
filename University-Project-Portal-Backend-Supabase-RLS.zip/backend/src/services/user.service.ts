import { supabaseAdmin } from '../config/db.js';
import type { UserRecord } from '../models/user.model.js';
import AppError from '../utils/AppError.js';

export function publicUser(u: UserRecord) {
  return { id:u.id, name:u.name, email:u.email, role:u.role, department:u.department ?? undefined, matricNumber:u.matricNumber ?? undefined, staffId:u.staffId ?? undefined, specialization:u.specialization ?? undefined };
}

export async function findByIdentifier(identifier: string, type: 'id'|'email') {
  let query = supabaseAdmin.from('profiles').select('*').limit(1);
  if (type === 'email') query = query.ilike('email', identifier.toLowerCase());
  else query = query.or(`matric_number.eq.${identifier},staff_id.eq.${identifier}`);
  const { data, error } = await query.maybeSingle();
  if (error) throw new AppError(error.message, 500);
  return data as UserRecord | null;
}

export async function getUser(id: string) {
  const { data, error } = await supabaseAdmin.from('profiles').select('*').eq('id', id).maybeSingle();
  if (error) throw new AppError(error.message, 500);
  return data as UserRecord | null;
}

export async function createUser(data:any) {
  if (data.password !== data.confirmPassword) throw new AppError('Passwords do not match.', 400);
  const email = data.identifierType === 'email'
    ? data.identifier.toLowerCase()
    : `${data.identifier.toLowerCase().replace(/[^a-z0-9]+/g,'.')}@university.edu`;

  const existing = await findByIdentifier(data.identifier, data.identifierType === 'email' ? 'email' : 'id');
  if (existing) throw new AppError('An account with that identifier already exists.', 409);

  const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
    email,
    password: data.password,
    email_confirm: true,
    user_metadata: { name: data.name, role: data.role, department: data.department ?? null, matricNumber: data.role === 'student' ? data.identifier : null, staffId: data.role !== 'student' ? data.identifier : null },
    app_metadata: { role: data.role },
  });
  if (error || !created.user) throw new AppError(error?.message ?? 'Unable to create account.', 400);

  const { data: profile, error: profileError } = await supabaseAdmin.from('profiles').select('*').eq('id', created.user.id).single();
  if (profileError) throw new AppError(profileError.message, 500);
  return profile as UserRecord;
}
