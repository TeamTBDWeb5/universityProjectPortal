import { supabaseAdmin } from '../config/db.js';
import AppError from '../utils/AppError.js';

export function serialize(t:any){return {id:t.id,title:t.title,description:t.description,lecturerId:t.lecturer_id,lecturerName:t.lecturer?.name??'',specialization:t.lecturer?.specialization??'',department:t.department,researchArea:t.research_area,maxStudents:t.max_students,enrolledStudents:t.enrolled_students,status:t.status,createdAt:t.created_at};}

export async function listTopics(q:any){
  let query=supabaseAdmin.from('topics').select('*, lecturer:profiles!topics_lecturer_id_fkey(name,specialization)').in('status',['available','approved','full']).order('created_at',{ascending:false});
  if(q.department) query=query.eq('department',q.department);
  if(q.researchArea) query=query.eq('research_area',q.researchArea);
  if(q.search) query=query.or(`title.ilike.%${q.search}%,description.ilike.%${q.search}%,research_area.ilike.%${q.search}%`);
  const {data,error}=await query; if(error) throw new AppError(error.message,500); return (data??[]).map(serialize);
}

export async function mine(userId:string){const {data,error}=await supabaseAdmin.from('topics').select('*, lecturer:profiles!topics_lecturer_id_fkey(name,specialization)').eq('lecturer_id',userId).order('created_at',{ascending:false});if(error)throw new AppError(error.message,500);return(data??[]).map(serialize);}

export async function createTopic(userId:string,data:any){const {data:row,error}=await supabaseAdmin.from('topics').insert({title:data.title,description:data.description,lecturer_id:userId,department:data.department,research_area:data.researchArea,max_students:data.maxStudents,status:'pending_approval'}).select('*, lecturer:profiles!topics_lecturer_id_fkey(name,specialization)').single();if(error)throw new AppError(error.message,400);return serialize(row);}

export async function selectTopic(studentId:string,topicId:string){
  const {data:existing}=await supabaseAdmin.from('projects').select('id').eq('student_id',studentId).maybeSingle(); if(existing)throw new AppError('You already have a project allocation.',409);
  const {data:t,error}=await supabaseAdmin.from('topics').select('*').eq('id',topicId).single(); if(error||!t)throw new AppError('Topic not found.',404);
  if(!['available','approved'].includes(t.status)||t.enrolled_students>=t.max_students)throw new AppError('Topic is not available.',409);
  const {error:pe}=await supabaseAdmin.from('projects').insert({student_id:studentId,topic_id:topicId,supervisor_id:t.lecturer_id,status:'active',supervisor_approval_status:'Pending',milestones:[]});if(pe)throw new AppError(pe.message,400);
  const enrolled=t.enrolled_students+1; const {error:te}=await supabaseAdmin.from('topics').update({enrolled_students:enrolled,status:enrolled>=t.max_students?'full':t.status}).eq('id',topicId);if(te)throw new AppError(te.message,500);
}

export async function proposeTopic(studentId:string,data:any){const {data:student}=await supabaseAdmin.from('profiles').select('*').eq('id',studentId).single();const {data:lecturer}=await supabaseAdmin.from('profiles').select('id').eq('role','lecturer').limit(1).single();if(!student||!lecturer)throw new AppError('No lecturer is currently available.',503);const {data:topic,error}=await supabaseAdmin.from('topics').insert({title:data.title,description:data.description,lecturer_id:lecturer.id,department:student.department??'General',research_area:'Student Proposal',max_students:1,status:'pending_approval'}).select('id').single();if(error)throw new AppError(error.message,400);return topic;}
