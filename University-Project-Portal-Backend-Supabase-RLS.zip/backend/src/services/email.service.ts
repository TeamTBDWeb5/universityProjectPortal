export async function sendEmail(to:string,subject:string,text:string){console.log(`[EMAIL PLACEHOLDER] ${to}: ${subject}\n${text}`);}
