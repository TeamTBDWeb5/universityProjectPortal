import {app} from './app.js';
import {env,assertEnv} from './config/env.js';
import {connectDB,disconnectDB} from './config/db.js';
assertEnv();
await connectDB();
const server=app.listen(env.port,()=>console.log(`API running on http://localhost:${env.port}`));
const shutdown=async()=>{server.close();await disconnectDB();process.exit(0)};
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
